(function(Saola) {
	var docData = {"ascene":{"aa":true,"autoKeyTime":0,"currentTime":0,"id":1,"k":8,"n":"Across-Scene Layer","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":[0,0,"100%","100%",0]}]],"sceneLayer":1,"st":[0,0],"timelines":[{"dur":0,"id":1,"n":"Timeline"}]},"dur":0,"e":[[50,[103,6]],[56,[103,4]]],"h":576,"k":116481,"mm":[0,2],"mpv":2,"resourceFolder":"resources","resources":[[55,3,"landscape",{"af":false,"align":4,"ascene":{"aa":true,"autoKeyTime":0,"currentTime":0,"id":1,"k":8,"n":"Across-Scene Layer","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":[0,0,"100%","100%",0]}]],"sceneLayer":1,"st":[0,0],"timelines":[{"dur":0,"id":1,"n":"Timeline"}]},"dur":15363,"scenes":[{"aa":true,"autoKeyTime":0,"currentTime":2400,"elems":[{"id":2,"k":5,"n":"color","rp":[[0,0,{"f":[1,255,255,255,255],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[-49.25,0,26.6667,23.3333,0],"txt":["","'Arial'",18,[255,255,255,255],[0,0,0,0],"normal",0,0,0,4,128,120,0,0,0]}]]},{"ap":false,"ct":false,"id":3,"k":2,"lo":false,"n":"Outro Logo PAM Jaya","pl":true,"rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[3.979039320256561e-13,0,1024,576,0]}]],"rs":289,"vol":100}],"id":4,"k":8,"n":"Scene_2_2","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"of":1,"pso":[50,50,1200,1],"r":[0,0,1024,576,0]}]],"sceneLayer":0,"st":[0,0],"timelines":[{"dur":8000,"id":1,"n":"Timeline","ra":[[0,0,[[2,[["fc",[{"d":0,"e":[255,255,255,255],"s":[255,255,255,255],"t":0}]]],{}],[3,[["pb",[{"a":[2,0,1],"d":7083,"t":0}]]],{}]]]],"t":[[8000,[[100,-2,1,1000,7]]]]}]},{"aa":true,"autoKeyTime":0,"currentTime":3199,"elems":[{"elems":[{"elems":[{"id":369,"it":0,"k":0,"n":"img0001","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[467.50000000000006,5,1024,576,0]}]],"rs":254},{"id":380,"it":0,"k":0,"n":"img0001_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[0,0,1986,616,0]}]],"rs":276},{"ap":true,"id":398,"k":7,"n":"awan","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":["22.9424%","0.811688%","50.2524%","93.5065%",0]}]],"rs":285},{"id":382,"it":0,"k":0,"n":"img0003","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[94.71199999999999,150,1828,275,0]}]],"rs":273},{"id":384,"it":0,"k":0,"n":"img0005","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[311.924,208,1337,212,0]}]],"rs":272},{"id":383,"it":0,"k":0,"n":"img0004","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[19.71199999999999,417,2018.0000000000005,172,0]}]],"rs":255},{"elems":[{"id":395,"it":0,"k":0,"n":"01_pohon0001_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[59.5,321.917,186.19047619047615,17,0]}]],"rs":274},{"ap":true,"id":396,"k":7,"n":"anim_pohon1_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[-7.812500001591616e-06,0,309,332.4169921875,0]}]],"rs":283},{"ap":true,"id":397,"k":7,"n":"rumput1_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[78,269.417,153,68,0]}]],"rs":259}],"id":394,"k":6,"n":"tumbuhan2","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[1333.5,137,309,342.468994140625,0],"t":[[],[70,70,100],[],[-2.625584602355957e-05,1.0165756975766271e-05,0]]}]]},{"id":400,"it":0,"k":0,"n":"Birds-GIF_re","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[1037.6,-41.8,534,312,0],"t":[[],[70,70,100]]}]],"rs":242},{"id":385,"it":0,"k":0,"n":"img0006","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[527.212,95,905,382,0]}]],"rs":256},{"elems":[{"id":390,"it":0,"k":0,"n":"01_pohon0001","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[3.4999921874999984,321.96900000000005,230,21,0]}]],"rs":274},{"ap":true,"id":391,"k":7,"n":"rumput2","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[160.1669921875,284.468994140625,58,48,0]}]],"rs":261},{"ap":true,"id":392,"k":7,"n":"anim_pohon1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[-7.812500001591616e-06,0,309,332.4169921875,0]}]],"rs":283},{"ap":true,"id":393,"k":7,"n":"rumput1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[3.5,271.469,153,68,0]}]],"rs":259}],"id":389,"k":6,"n":"tumbuhan1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[424.212,150,309,342.468994140625,0]}]]}],"id":399,"k":6,"n":"bg","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[-467.5,-5,2037.7120361328125,616,0]}]]},{"elems":[{"id":372,"it":0,"k":0,"n":"boxbiru","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[-6.10351561771694e-05,-29,1024,119,0],"t":[[],[150,100,100],[],[4.218059041249944e-05,29.00000006865332,0]]}]],"rs":253},{"id":373,"it":0,"k":0,"n":"namamedia_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[-696.5720610351563,50.928,637,47,0],"t":[[],[],[],[736.2841012137276,10.571799931346675,0]]}]],"rs":257},{"id":374,"it":0,"k":0,"n":"kursus_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[-1060.5800610351562,-174.756,965,66,0],"t":[[],[],[],[1100.2921263392002,176,0]]}]],"rs":252}],"id":379,"k":6,"n":"judul","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[1.13687e-13,431,1023.9999389648438,119,0]}]]}],"id":388,"k":6,"n":"mask","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"of":1,"r":[0,0,1024,576,0]}]]}],"id":6,"k":8,"n":"gainattention","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"of":1,"pso":[50,50,1200,1],"r":[0,0,1024,576,0]}]],"sceneLayer":0,"st":[0,0],"timelines":[{"dur":7363,"id":1,"l":{"01":1250},"n":"Timeline","ra":[[0,0,[[372,[["pos",[{"cp":[[-1289.9999578194097,27.46900000000005,-1289.9999578194097,27.46900000000005,-1289.9999578194097,27.46900000000005],[4.218059041249944e-05,29.00000006865332,4.218059041249944e-05,29.00000006865332,4.218059041249944e-05,29.00000006865332]],"d":749,"e":[4.218059041249944e-05,29.00000006865332],"es":34,"s":[-1289.9999578194097,27.46900000000005],"t":1250}]]],{}],[373,[["pos",[{"cp":[[50.13963099888383,10.571799931346675,50.13963099888383,10.571799931346675,50.13963099888383,10.571799931346675],[736.2841012137276,10.571799931346675,736.2841012137276,10.571799931346675,736.2841012137276,10.571799931346675]],"d":741,"e":[736.2841012137276,10.571799931346675],"es":34,"s":[50.13963099888383,10.571799931346675],"t":1640}]]],{}],[374,[["pos",[{"cp":[[204.2921263392002,176,204.2921263392002,176,204.2921263392002,176],[1100.2921263392002,176,1100.2921263392002,176,1100.2921263392002,176]],"d":750,"e":[1100.2921263392002,176],"es":34,"s":[204.2921263392002,176],"t":1500}]]],{}],[382,[["tp",[{"d":1000,"e":"150px","es":6,"s":"1059px","t":0}]]],{}],[383,[["tp",[{"d":1000,"e":"417px","es":6,"s":"1076px","t":0}]]],{}],[384,[["tp",[{"d":1000,"e":"208px","es":6,"s":"1046px","t":0}]]],{}],[385,[["tp",[{"d":1000,"e":"95px","es":6,"s":"726px","t":0}]]],{}],[389,[["tp",[{"d":1000,"e":"150px","es":6,"s":"739px","t":0}]]],{}],[394,[["tp",[{"d":996,"e":"137px","es":6,"s":"770px","t":0}]]],{}],[398,[["tp",[{"d":1000,"e":"0.811688%","es":6,"s":"94.3182%","t":0}]]],{}],[379,[["d",[{"d":0,"e":"0","s":"0","t":1000},{"d":0,"e":"1","s":"1","t":1250}]]],{}],[400,[["d",[{"d":0,"e":"1","s":"0","t":2500}]]],{}]]]],"t":[[0,[[103,29]]],[1250,[[103,15]]],[7363,[[103,28]]]]}]}]}],[238,1,"01",["01.mp3"]],[239,2,"Outro Logo PAM Jaya",["Outro Logo PAM Jaya.mp4"]],[240,0,"chart0005","chart0005.png"],[241,3,"symbol bulet1",{"af":false,"align":4,"ascene":{"aa":true,"autoKeyTime":0,"currentTime":0,"id":1,"k":8,"n":"Across-Scene Layer","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":[0,0,"100%","100%",0]}]],"sceneLayer":1,"st":[0,0],"timelines":[{"dur":0,"id":1,"n":"Timeline"}]},"dur":2000,"scenes":[{"aa":true,"autoKeyTime":0,"currentTime":1052,"elems":[{"id":120,"it":0,"k":0,"n":"chart0005","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[1.2532552204902458e-05,1.4078776018777717e-05,356,356,0]}]],"rs":240}],"id":1,"k":8,"n":"Scene_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":["0%","0%","100%","100%",0]}]],"sceneLayer":0,"st":[0,0],"timelines":[{"dur":2000,"id":1,"n":"Timeline","ra":[[0,0,[[120,[["sX",[{"d":1000,"e":90,"es":0,"s":100,"t":0},{"d":1000,"e":100,"es":0,"s":90,"t":1000}]],["sY",[{"d":1000,"e":90,"es":0,"s":100,"t":0},{"d":1000,"e":100,"es":0,"s":90,"t":1000}]]],{}]]]],"t":[[2000,[[1,-1,1,0]]]]}]}]}],[242,0,"Birds-GIF_re","Birds-GIF_re.gif"],[243,0,"chart0002","chart0002.png"],[244,3,"symbol bulet4",{"af":false,"align":4,"ascene":{"aa":true,"autoKeyTime":0,"currentTime":0,"id":1,"k":8,"n":"Across-Scene Layer","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":[0,0,"100%","100%",0]}]],"sceneLayer":1,"st":[0,0],"timelines":[{"dur":0,"id":1,"n":"Timeline"}]},"dur":2000,"scenes":[{"aa":true,"autoKeyTime":0,"currentTime":2000,"elems":[{"id":117,"it":0,"k":0,"n":"chart0002","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[1.2532552204902458e-05,1.4078776018777717e-05,1089,1087,0]}]],"rs":243}],"id":1,"k":8,"n":"Scene_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":["0%","0%","100%","100%",0]}]],"sceneLayer":0,"st":[0,0],"timelines":[{"dur":2000,"id":1,"n":"Timeline","ra":[[0,0,[[117,[["sX",[{"d":1000,"e":90,"es":0,"s":100,"t":0},{"d":1000,"e":100,"es":0,"s":90,"t":1000}]],["sY",[{"d":1000,"e":90,"es":0,"s":100,"t":0},{"d":1000,"e":100,"es":0,"s":90,"t":1000}]]],{}]]]],"t":[[2000,[[1,-1,1,0]]]]}]}]}],[245,0,"chart0003","chart0003.png"],[246,3,"symbol bulet3",{"af":false,"align":4,"ascene":{"aa":true,"autoKeyTime":0,"currentTime":0,"id":1,"k":8,"n":"Across-Scene Layer","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":[0,0,"100%","100%",0]}]],"sceneLayer":1,"st":[0,0],"timelines":[{"dur":0,"id":1,"n":"Timeline"}]},"dur":2000,"scenes":[{"aa":true,"autoKeyTime":0,"currentTime":2000,"elems":[{"id":118,"it":0,"k":0,"n":"chart0003","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[1.2532552204902458e-05,1.4078776018777717e-05,873,871,0]}]],"rs":245}],"id":1,"k":8,"n":"Scene_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":["0%","0%","100%","100%",0]}]],"sceneLayer":0,"st":[0,0],"timelines":[{"dur":2000,"id":1,"n":"Timeline","ra":[[0,0,[[118,[["sX",[{"d":1000,"e":90,"es":0,"s":100,"t":0},{"d":1000,"e":100,"es":0,"s":90,"t":1000}]],["sY",[{"d":1000,"e":90,"es":0,"s":100,"t":0},{"d":1000,"e":100,"es":0,"s":90,"t":1000}]]],{}]]]],"t":[[2000,[[1,-1,1,0]]]]}]}]}],[247,0,"chart0004","chart0004.png"],[248,3,"symbol bulet2",{"af":false,"align":4,"ascene":{"aa":true,"autoKeyTime":0,"currentTime":0,"id":1,"k":8,"n":"Across-Scene Layer","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":[0,0,"100%","100%",0]}]],"sceneLayer":1,"st":[0,0],"timelines":[{"dur":0,"id":1,"n":"Timeline"}]},"dur":2000,"scenes":[{"aa":true,"autoKeyTime":0,"currentTime":2000,"elems":[{"id":119,"it":0,"k":0,"n":"chart0004","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[1.2532552204902458e-05,1.4078776018777717e-05,609,608,0]}]],"rs":247}],"id":1,"k":8,"n":"Scene_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":["0%","0%","100%","100%",0]}]],"sceneLayer":0,"st":[0,0],"timelines":[{"dur":2000,"id":1,"n":"Timeline","ra":[[0,0,[[119,[["sX",[{"d":1000,"e":90,"es":0,"s":100,"t":0},{"d":1000,"e":100,"es":0,"s":90,"t":1000}]],["sY",[{"d":1000,"e":90,"es":0,"s":100,"t":0},{"d":1000,"e":100,"es":0,"s":90,"t":1000}]]],{}]]]],"t":[[2000,[[1,-1,1,0]]]]}]}]}],[249,0,"chart0020","chart0020.png"],[250,0,"chart0001","chart0001.png"],[251,3,"symbol bulet5",{"af":false,"align":4,"ascene":{"aa":true,"autoKeyTime":0,"currentTime":0,"id":1,"k":8,"n":"Across-Scene Layer","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":[0,0,"100%","100%",0]}]],"sceneLayer":1,"st":[0,0],"timelines":[{"dur":0,"id":1,"n":"Timeline"}]},"dur":2000,"scenes":[{"aa":true,"autoKeyTime":0,"currentTime":2000,"elems":[{"id":116,"it":0,"k":0,"n":"chart0001","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[1.2532552204902458e-05,1.4078776018777717e-05,1277,1276,0]}]],"rs":250}],"id":1,"k":8,"n":"Scene_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":["0%","0%","100%","100%",0]}]],"sceneLayer":0,"st":[0,0],"timelines":[{"dur":2000,"id":1,"n":"Timeline","ra":[[0,0,[[116,[["sX",[{"d":1000,"e":90,"es":0,"s":100,"t":0},{"d":1000,"e":100,"es":0,"s":90,"t":1000}]],["sY",[{"d":1000,"e":90,"es":0,"s":100,"t":0},{"d":1000,"e":100,"es":0,"s":90,"t":1000}]]],{}]]]],"t":[[2000,[[1,-1,1,0]]]]}]}]}],[252,0,"img0007","img0007.png"],[253,0,"img0005","img0005.png"],[254,0,"img0001","img0001.png"],[255,0,"img0004_1","img0004_1.png"],[256,0,"img0006","img0006.png"],[257,0,"img0006_1","img0006_1.png"],[258,0,"01_pohon0003","01_pohon0003.png"],[259,3,"rumput1",{"af":false,"align":4,"ascene":{"aa":true,"autoKeyTime":0,"currentTime":0,"id":1,"k":8,"n":"Across-Scene Layer","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":[0,0,"100%","100%",0]}]],"sceneLayer":1,"st":[0,0],"timelines":[{"dur":0,"id":1,"n":"Timeline"}]},"dur":2000,"scenes":[{"aa":true,"autoKeyTime":0,"currentTime":2000,"elems":[{"id":18,"it":0,"k":0,"n":"01_pohon0003","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[-7.812500001591616e-06,5.8593749940882844e-06,153,68,0],"t":[[],[],[],[],[50,99,0]]}]],"rs":258}],"id":1,"k":8,"n":"Scene_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":["0%","0%","100%","100%",0]}]],"sceneLayer":0,"st":[0,0],"timelines":[{"dur":2000,"id":1,"n":"Timeline","ra":[[0,0,[[18,[["skX",[{"d":500,"e":"2deg","es":0,"s":"0deg","t":0},{"d":500,"e":"0deg","es":0,"s":"2deg","t":500},{"d":500,"e":"-2deg","es":0,"s":"0deg","t":1000},{"d":500,"e":"0deg","es":0,"s":"-2deg","t":1500}]]],{}]]]],"t":[[2000,[[1,-1,1,0]]]]}]}]}],[260,0,"01_pohon0002","01_pohon0002.png"],[261,3,"rumput2",{"af":false,"align":4,"ascene":{"aa":true,"autoKeyTime":0,"currentTime":0,"id":1,"k":8,"n":"Across-Scene Layer","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":[0,0,"100%","100%",0]}]],"sceneLayer":1,"st":[0,0],"timelines":[{"dur":0,"id":1,"n":"Timeline"}]},"dur":2000,"scenes":[{"aa":true,"autoKeyTime":0,"currentTime":2000,"elems":[{"id":17,"it":0,"k":0,"n":"01_pohon0002","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[0,5.8593749940882844e-06,58,48,0]}]],"rs":260}],"id":1,"k":8,"n":"Scene_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":["0%","0%","100%","100%",0]}]],"sceneLayer":0,"st":[0,0],"timelines":[{"dur":2000,"id":1,"n":"Timeline","ra":[[0,0,[[17,[["skX",[{"d":500,"e":"-2deg","es":0,"s":"0deg","t":0},{"d":500,"e":"0deg","es":0,"s":"-2deg","t":500},{"d":500,"e":"2deg","es":0,"s":"0deg","t":1000},{"d":500,"e":"0deg","es":0,"s":"2deg","t":1500}]]],{}]]]],"t":[[2000,[[1,-1,1,0]]]]}]}]}],[262,0,"chart0007","chart0007.png"],[263,0,"chart0009","chart0009.png"],[264,0,"chart0012","chart0012.png"],[265,0,"chart0014","chart0014.png"],[266,0,"chart0013","chart0013.png"],[267,0,"chart0008","chart0008.png"],[268,0,"chart0010","chart0010.png"],[269,0,"chart0015","chart0015.png"],[270,0,"chart0011","chart0011.png"],[271,0,"chart0016","chart0016.png"],[272,0,"img0005_1","img0005_1.png"],[273,0,"img0003_1","img0003_1.png"],[274,0,"01_pohon0001","01_pohon0001.png"],[275,0,"chart0006","chart0006.png"],[276,0,"img0001_1","img0001_1.png"],[277,0,"01_pohon0009","01_pohon0009.png"],[278,0,"01_pohon0011","01_pohon0011.png"],[279,0,"01_pohon0007","01_pohon0007.png"],[280,0,"01_pohon0006","01_pohon0006.png"],[281,0,"01_pohon0008","01_pohon0008.png"],[282,0,"01_pohon0010","01_pohon0010.png"],[283,3,"anim_pohon1",{"af":false,"align":4,"ascene":{"aa":true,"autoKeyTime":0,"currentTime":0,"id":1,"k":8,"n":"Across-Scene Layer","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":[0,0,"100%","100%",0]}]],"sceneLayer":1,"st":[0,0],"timelines":[{"dur":0,"id":1,"n":"Timeline"}]},"dur":6000,"scenes":[{"aa":true,"autoKeyTime":0,"currentTime":6000,"elems":[{"elems":[{"elems":[{"id":8,"it":0,"k":0,"n":"01_pohon0006","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[-7.812499973169906e-06,-7.812500001591616e-06,309,235,0],"t":[[],[],[],[],[50,80,0]]}]],"rs":280},{"id":13,"it":0,"k":0,"n":"01_pohon0011","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[59.49999218750003,92.4169921875,219,240,0],"t":[[],[],[],[],[45,99,0]]}]],"rs":278}],"id":14,"k":6,"n":"Group_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[0,0,309,332.4169921875,0],"t":[[],[],[],[],[50,99,0]]}]]},{"id":9,"it":0,"k":0,"n":"01_pohon0007","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[122.99999218750003,74.4999921875,149,124,0],"t":[[],[],[],[14,-23.5,0]]}]],"rs":279},{"id":10,"it":0,"k":0,"n":"01_pohon0008","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[4.499992187500027,92.4169921875,149,125,0]}]],"rs":281},{"id":11,"it":0,"k":0,"n":"01_pohon0009","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[69.49999218750003,74.4999921875,88,61,0],"t":[[],[],[],[-42.515883015873015,60.999999999999986,0]]}]],"rs":277},{"id":12,"it":0,"k":0,"n":"01_pohon0010","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[177.99999218750003,56.9999921875,57,48,0],"t":[[],[],[],[11,44.58366666666669,0]]}]],"rs":282}],"id":15,"k":6,"n":"Group_2","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[0,0,309,332.4169921875,0]}]]}],"id":1,"k":8,"n":"Scene_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":["0%","0%","100%","100%",0]}]],"sceneLayer":0,"st":[0,0],"timelines":[{"dur":6000,"id":1,"n":"Timeline","ra":[[0,0,[[14,[["skX",[{"d":1500,"e":"1deg","es":0,"s":"0deg","t":0},{"d":1500,"e":"0deg","es":0,"s":"1deg","t":1500},{"d":1500,"e":"-1deg","es":0,"s":"0deg","t":3000},{"d":1500,"e":"0deg","es":0,"s":"-1deg","t":4500}]]],{}],[8,[["skX",[{"d":1500,"e":"1deg","es":0,"s":"0deg","t":0},{"d":1500,"e":"0deg","es":0,"s":"1deg","t":1500},{"d":1500,"e":"-1deg","es":0,"s":"0deg","t":3000},{"d":1500,"e":"0deg","es":0,"s":"-1deg","t":4500}]]],{}],[9,[["pos",[{"cp":[[14,-23.5,14,-23.5,14,-23.5],[10,-23.5,10,-23.5,10,-23.5]],"d":1504,"e":[10,-23.5],"es":0,"s":[14,-23.5],"t":0},{"cp":[[10,-23.5,10,-23.5,10,-23.5],[14,-23.5,14,-23.5,14,-23.5],[14,-23.5,14,-23.5,14,-23.5],[14,-23.5,14,-23.5,14,-23.5],[17.333333333333332,-23.5,15.778692272519432,-23.5,17.333333333333332,-23.5]],"d":1488,"e":[17.333333333333332,-23.5],"es":0,"s":[10,-23.5],"t":1504},{"cp":[[17.333333333333332,-23.5,15.778692272519432,-23.5,17.333333333333332,-23.5],[22.333333333333332,-23.5,20.778692272519432,-23.5,22.333333333333332,-23.5]],"d":1511,"e":[22.333333333333332,-23.5],"es":0,"s":[17.333333333333332,-23.5],"t":2992},{"cp":[[22.333333333333332,-23.5,20.778692272519432,-23.5,22.333333333333332,-23.5],[14,-23.5,14,-23.5,14,-23.5]],"d":1496,"e":[14,-23.5],"es":0,"s":[22.333333333333332,-23.5],"t":4503}]]],{}],[10,[["pos",[{"cp":[[0,0,0,0,0,0],[-6,0,-6,0,-6,0]],"d":1504,"e":[-6,0],"es":0,"s":[0,0],"t":0},{"cp":[[-6,0,-6,0,-6,0],[0,0,0,0,0,0]],"d":1488,"e":[0,0],"es":0,"s":[-6,0],"t":1504},{"cp":[[0,0,0,0,0,0],[6,0,6,0,6,0]],"d":1511,"e":[6,0],"es":0,"s":[0,0],"t":2992},{"cp":[[6,0,6,0,6,0],[0,0,0,0,0,0]],"d":1496,"e":[0,0],"es":0,"s":[6,0],"t":4503}]]],{}],[11,[["pos",[{"cp":[[-42.515883015873015,60.999999999999986,-42.515883015873015,60.999999999999986,-42.515883015873015,60.999999999999986],[-54.515883015873015,60.999999999999986,-54.515883015873015,60.999999999999986,-54.515883015873015,60.999999999999986]],"d":1504,"e":[-54.515883015873015,60.999999999999986],"es":0,"s":[-42.515883015873015,60.999999999999986],"t":0},{"cp":[[-54.515883015873015,60.999999999999986,-54.515883015873015,60.999999999999986,-54.515883015873015,60.999999999999986],[-48.515883015873015,60.999999999999986,-48.515883015873015,60.999999999999986,-48.515883015873015,60.999999999999986],[-42.515883015873015,60.999999999999986,-42.515883015873015,60.999999999999986,-42.515883015873015,60.999999999999986]],"d":1488,"e":[-42.515883015873015,60.999999999999986],"es":0,"s":[-54.515883015873015,60.999999999999986],"t":1504},{"cp":[[-42.515883015873015,60.999999999999986,-42.515883015873015,60.999999999999986,-42.515883015873015,60.999999999999986],[-36.515883015873015,60.999999999999986,-36.515883015873015,60.999999999999986,-36.515883015873015,60.999999999999986],[-30.515883015873015,60.999999999999986,-30.515883015873015,60.999999999999986,-30.515883015873015,60.999999999999986]],"d":1511,"e":[-30.515883015873015,60.999999999999986],"es":0,"s":[-42.515883015873015,60.999999999999986],"t":2992},{"cp":[[-30.515883015873015,60.999999999999986,-30.515883015873015,60.999999999999986,-30.515883015873015,60.999999999999986],[-42.515883015873015,60.999999999999986,-42.515883015873015,60.999999999999986,-42.515883015873015,60.999999999999986]],"d":1496,"e":[-42.515883015873015,60.999999999999986],"es":0,"s":[-30.515883015873015,60.999999999999986],"t":4503}]]],{}],[12,[["pos",[{"cp":[[11,44.58366666666669,11,44.58366666666669,11,44.58366666666669],[7,44.58366666666669,7,44.58366666666669,7,44.58366666666669],[0,44.58366666666669,0,44.58366666666669,0,44.58366666666669]],"d":1504,"e":[0,44.58366666666669],"es":0,"s":[11,44.58366666666669],"t":0},{"cp":[[0,44.58366666666669,0,44.58366666666669,0,44.58366666666669],[11,44.58366666666669,11,44.58366666666669,11,44.58366666666669]],"d":1488,"e":[11,44.58366666666669],"es":0,"s":[0,44.58366666666669],"t":1504},{"cp":[[11,44.58366666666669,11,44.58366666666669,11,44.58366666666669],[20,44.58366666666669,20,44.58366666666669,20,44.58366666666669],[29,44.58366666666669,29,44.58366666666669,29,44.58366666666669]],"d":1511,"e":[29,44.58366666666669],"es":0,"s":[11,44.58366666666669],"t":2992},{"cp":[[29,44.58366666666669,29,44.58366666666669,29,44.58366666666669],[11,44.58366666666669,11,44.58366666666669,11,44.58366666666669]],"d":1496,"e":[11,44.58366666666669],"es":0,"s":[29,44.58366666666669],"t":4503}]]],{}]]]],"t":[[6000,[[1,-1,1,0]]]]}]}]}],[284,0,"img0002_1","img0002_1.png"],[285,3,"awan",{"af":false,"align":4,"ascene":{"aa":true,"autoKeyTime":0,"currentTime":0,"id":1,"k":8,"n":"Across-Scene Layer","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":[0,0,"100%","100%",0]}]],"sceneLayer":1,"st":[0,0],"timelines":[{"dur":0,"id":1,"n":"Timeline"}]},"dur":239750,"scenes":[{"aa":true,"autoKeyTime":0,"currentTime":239750,"elems":[{"id":381,"it":0,"k":0,"n":"img0002","rp":[[0,0,{"d":0,"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[-94.00003613281251,-79,1118,487,0]}]],"rs":284},{"elems":[{"id":382,"it":0,"k":0,"n":"img0002_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[-5.615234385913936e-06,0,1118,487,0]}]],"rs":284},{"id":383,"it":0,"k":0,"n":"img0002_1_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[1117.9999943847656,0,1118,487,0],"t":[[],[-100,100,100]]}]],"rs":284},{"id":385,"it":0,"k":0,"n":"img0002_1_1_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"ir":[0,0,"100%","100%"],"l":["none"],"r":[2235.9979943847657,0,1118,487,0]}]],"rs":284}],"id":386,"k":6,"n":"Group_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[-235.28799438476562,-79,3353.9979553222656,487,0]}]]}],"id":1,"k":8,"n":"Scene_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"pso":[50,50,1200,1],"r":["0%","0%","100%","100%",0]}]],"sceneLayer":0,"st":[0,0],"timelines":[{"dur":239750,"id":1,"n":"Timeline","ra":[[0,0,[[381,[["d",[{"d":0,"e":"0","s":"0","t":0}]]],{}],[386,[["lt",[{"d":239750,"e":"-2330px","es":6,"s":"-235px","t":0}]]],{}]]]],"t":[[239750,[[1,-1,1,0]]]]}]}]}],[286,0,"chart0018","chart0018.png"],[287,0,"chart0019","chart0019.png"],[288,0,"chart0017","chart0017.png"],[289,2,"Intro PAM Jaya with music",["Intro PAM Jaya with music.mp4"]]],"scenes":[{"aa":true,"autoKeyTime":0,"currentTime":17000,"elems":[{"ap":true,"id":56,"k":7,"n":"landscape","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"r":[0,0,1024,576,0]}]],"rs":55}],"id":16,"k":8,"n":"Scene_1","rp":[[0,0,{"f":[0],"fe":[0,0,100,100,100,0,0,0],"l":["none"],"of":1,"pso":[50,50,1200,1],"r":[0,0,1024,576,0]}]],"sceneLayer":0,"st":[0,0],"timelines":[{"dur":0,"id":1,"n":"Timeline"}]}],"v":5,"w":1024};
	var f = [];
	var onWindowResize = function onWindowResize(doc, e) {
		scaleFit(doc);
	};
	f.push([4, "onWindowResize", onWindowResize]);
	var scaleFit = function scaleFit(doc) {
		var docNode = doc.dom;
		var containerNode = docNode.parentNode;
		var scene = doc.getScene();
		try {
			if (containerNode.offsetWidth > containerNode.offsetHeight) {
				scene.setSize(1024, 576);
			} else {
				scene.setSize(576, 1024);
			}
			
			var scale = Math.min(containerNode.offsetWidth / docNode.offsetWidth, 
						containerNode.offsetHeight / docNode.offsetHeight);
				
			docNode.style.top = '';
			docNode.style.bottom = '';
			docNode.style.left = '';
			docNode.style.right = '';
	
			// change orientation scene
			if (containerNode.offsetWidth > containerNode.offsetHeight) {
				landscape.show(true);
				portrait.show(false);
			} else {
				landscape.show(false);
				portrait.show(true);
			}
		} catch(err) {
			//console.log('Error: ' + err.message);
		}
	};
	f.push([5, "scaleFit", scaleFit]);
	var onSceneActive = function onSceneActive(doc, e) {
		Initialize(doc);
		
		scaleFit(doc);
	};
	f.push([6, "onSceneActive", onSceneActive]);
	var Initialize = function Initialize(doc) {
		window.stEndPage = false;
		window.StopPosition = false;
		
		window.landscape = doc.getElement('landscape');
		window.portrait = doc.getElement('portrait');
	};
	f.push([7, "Initialize", Initialize]);
	var PlayAudio = function PlayAudio(name, mute) {
		try {
			parent.onSoundMute = mute;
			parent.AtomiSaola.docs[1].getFunction('AudioPlay')(name, mute);
		} catch(err) {
			console.log('Error: ' + err.message);
		}
	};
	f.push([12, "PlayAudio", PlayAudio]);
	var StopAudio = function StopAudio(doc, name) {
		var audio = doc.getElement(name).mediaDom;
		audio.pause();
	};
	f.push([14, "StopAudio", StopAudio]);
	var onPlayAudio = function onPlayAudio(doc, e) {
		var timeline = doc.getTimeline();
		var timestamp = timeline.getTimestamp();
		var label = '00';
		for (x in timeline.labels) {
			if (timeline.labels[x] == timestamp) {
				label = x;
			}
		}
		try {
			parent.onSoundMute = false;
			parent.AtomiSaola.docs[1].getFunction('AudioPlayOnStopLoading')(label, false);
		} catch(err) {
			console.log('Error: ' + err.message);
		}
	};
	f.push([15, "onPlayAudio", onPlayAudio]);
	var ResumeAudio = function ResumeAudio(doc, name, vol, mute, loop) {
		var audio = doc.getElement(name).mediaDom;
		//audio.currentTime = currentTime;
		audio.volume = vol;
		audio.muted = mute;
		audio.loop = loop;
		audio.play();
	};
	f.push([16, "ResumeAudio", ResumeAudio]);
	var PauseFrame = function PauseFrame(doc) {
		var portrait = doc.getElement('portrait');
		var landscape = doc.getElement('landscape');	
		
		doc.pause();
		portrait.pause();
		landscape.pause();
		
		StopAudio(doc, 'bgm');
		StopAudio(doc, 'm00c01p01');
	};
	f.push([17, "PauseFrame", PauseFrame]);
	var ResumeFrame = function ResumeFrame(doc) {
		var portrait = doc.getElement('portrait');
		var landscape = doc.getElement('landscape');	
		
		doc.play();
		portrait.play();
		landscape.play();
		
		ResumeAudio(doc, 'bgm', 1, false, true);
		ResumeAudio(doc, 'm00c01p01', AudioVolume, AudioMute, false);
	};
	f.push([18, "ResumeFrame", ResumeFrame]);
	var EndPage = function EndPage() {
		stEndPage = true;
		
		parent.AtomiSaola.docs[1].getFunction('EndPage')();
	};
	f.push([21, "EndPage", EndPage]);
	var onStopPosition = function onStopPosition(doc, e) {
		StopPosition = true;
	};
	f.push([27, "onStopPosition", onStopPosition]);
	var onEndPage = function onEndPage(doc, e) {
		EndPage();
	};
	f.push([28, "onEndPage", onEndPage]);
	var onChangeBackground = function onChangeBackground(doc, e) {
		ChangeBackground(doc.getElement('color').dom.style.backgroundColor);
	};
	f.push([29, "onChangeBackground", onChangeBackground]);
	var onSetSubtitle = function onSetSubtitle(doc, e) {
		var timeline = doc.getTimeline();
		var timestamp = timeline.getTimestamp();
		var label = 'lead_01';
		for (x in timeline.labels) {
			if (timeline.labels[x] == timestamp) {
				label = 'lead_' + x;
			}
		}
		
		doc.getElement(label).show(false);
		SetSubtitle(doc.getElement(label).textDom.innerHTML);
	};
	f.push([31, "onSetSubtitle", onSetSubtitle]);
	var ChangeBackground = function ChangeBackground(color) {
		try {
			parent.parent.AtomiSaola.docs[1].getFunction('ChangeBackground')(color);
		} catch(err) {
			console.log('Error: ' + err.message);
		}
	};
	f.push([33, "ChangeBackground", ChangeBackground]);
	var onHideSubtitle = function onHideSubtitle(doc, e) {
		HideSubtitle();
	};
	f.push([34, "onHideSubtitle", onHideSubtitle]);
	var SetSubtitle = function SetSubtitle(Value) {
		try {
			parent.parent.AtomiSaola.docs[1].getFunction('SetSubtitle')(Value);
		} catch(err) {
			console.log('Error: ' + err.message);
		}
	};
	f.push([35, "SetSubtitle", SetSubtitle]);
	var HideSubtitle = function HideSubtitle() {
		try {
			parent.parent.AtomiSaola.docs[1].getFunction('HideSubtitle')();
		} catch(err) {
			console.log('Error: ' + err.message);
		}
	};
	f.push([36, "HideSubtitle", HideSubtitle]);
	var onInitQuiz = function onInitQuiz(doc, e) {
		window.Button = new Array(false, false, false, false, false);
		window.Drop = new Array(false, false, false, false, false);
		window.Answer = new Array(1, 2, 3, 4, 5);
		window.ButtonAnswer = new Array(0, 0, 0, 0, 0);
		window.SelectedIndex = 0;
		window.MaxAttempt = 3;
		window.Attempt = 0;
		window.FinishQuiz = false;	
	};
	f.push([38, "onInitQuiz", onInitQuiz]);
	var ClickButton = function ClickButton(doc, index) {
		if (FinishQuiz == false) {
			Button[index - 1] = true;
			
			doc.getTimeline().play('p' + index, 1, false);
			
			var FoundIt = false;
			for (var i = 1; i <= Button.length; i++) {
				if (Button[i - 1] == false) {
					FoundIt = true;
					break;
				}
			}
			
			if (FoundIt == false) {
				doc.getElement('close').show(true);
				//EndPage();
			}
		}
	};
	f.push([39, "ClickButton", ClickButton]);
	var DropButton = function DropButton(doc, index) {
		if (SelectedIndex != 0) {
			if (Button[index - 1] == false) {
				doc.getElement('target_0' + index).getSymbolDoc().getTimeline().pause('target_0' + SelectedIndex);
				doc.getElement('drag_0' + SelectedIndex).getSymbolDoc().getTimeline().pause('close');
				Button[index - 1] = true;
				ButtonAnswer[index - 1] = SelectedIndex;
				Drop[SelectedIndex - 1] = true;
				SelectedIndex = 0;
				
				var FoundIt = false;
				for (var i = 0; i < Button.length; i++) {
					if (Button[i] == false) {
						FoundIt = true;
						//break;
					}
				}
				
				if (FoundIt == false) {
					//FoundIt = false;
					for (var i = 0; i < ButtonAnswer.length; i++) {
						//console.log(ButtonAnswer[i] + ' != ' + Answer[i]);
						if (ButtonAnswer[i] != Answer[i]) {
							FoundIt = true;
							//break;
						}
					}
					
					//console.log(FoundIt);
					doc.getElement('feedback').show(true);
					if (FoundIt == true) {
						Attempt++;
						if (Attempt < MaxAttempt) {
							doc.getElement('feedback').getSymbolDoc().getTimeline().play('salah', 1, false);
						} else {
							FinishQuiz = true;
							doc.getElement('feedback').getSymbolDoc().getTimeline().play('total', 1, false);
							ShowCorrectAnswer(doc);
						}
					} else {
						FinishQuiz = true;
						doc.getElement('feedback').getSymbolDoc().getTimeline().play('benar', 1, false);
					}
				}
			}
		} else {
			if (Button[index - 1] == true) {
				doc.getElement('target_0' + index).getSymbolDoc().getTimeline().pause('idle');
				doc.getElement('drag_0' + ButtonAnswer[index - 1]).getSymbolDoc().getTimeline().pause('idle');
				Drop[ButtonAnswer[index - 1] - 1] = false;
				Button[index - 1] = false;
				ButtonAnswer[index - 1] = 0;
			}
		}
	};
	f.push([40, "DropButton", DropButton]);
	var ResetButton = function ResetButton(doc) {
		for (var i = 0; i < Button.length; i++) {
			doc.getElement('target_0' + (i + 1)).getSymbolDoc().getTimeline().pause('idle');
			doc.getElement('drag_0' + (i + 1)).getSymbolDoc().getTimeline().pause('idle');
			Drop[i] = false;
			Button[i] = false;
			ButtonAnswer[i] = 0;
		}
	};
	f.push([41, "ResetButton", ResetButton]);
	var ShowCorrectAnswer = function ShowCorrectAnswer(doc) {
		for (var i = 0; i < Button.length; i++) {
			doc.getElement('target_0' + (i + 1)).getSymbolDoc().getTimeline().pause('target_0' + Answer[i]);
			doc.getElement('drag_0' + (i + 1)).getSymbolDoc().getTimeline().pause('close');
			Drop[i] = true;
			Button[i] = true;
			ButtonAnswer[i] = Answer[i];
		}
	};
	f.push([42, "ShowCorrectAnswer", ShowCorrectAnswer]);
	var onClickButton = function onClickButton(doc, e) {
		var id = parseInt(e.currentTarget.name.replace('btn_', ''));
		ClickButton(doc, id);
	};
	f.push([43, "onClickButton", onClickButton]);
	var onClickTarget = function onClickTarget(doc, e) {
		var id = parseInt(e.currentTarget.name.replace('target_', ''));
		DropButton(doc, id);
	};
	f.push([44, "onClickTarget", onClickTarget]);
	var onCloseFeedback = function onCloseFeedback(doc, e) {
		doc.parent.show(false);
		if (FinishQuiz == true) {
			//console.log(doc.parent.parent.getDoc().getTimeline());
			doc.parent.parent.getDoc().getTimeline().play('EndQuiz', 1, false);
		} else {
			ResetButton(doc.parent.parent.getDoc());
		}
	};
	f.push([45, "onCloseFeedback", onCloseFeedback]);
	docData.f = f;
	Saola.loadedDocs.push(docData);
}(AtomiSaola)); 